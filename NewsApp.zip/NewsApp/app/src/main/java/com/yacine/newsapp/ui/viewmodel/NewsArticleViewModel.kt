package com.yacine.newsapp.ui.viewmodel


import androidx.lifecycle.ViewModel



import javax.inject.Inject

/**
 * A container for [NewsArticles] related data to show on the UI.
 */
class NewsArticleViewModel @Inject constructor(

) : ViewModel() {


}