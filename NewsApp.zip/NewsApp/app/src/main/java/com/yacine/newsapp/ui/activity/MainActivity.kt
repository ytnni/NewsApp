package com.yacine.newsapp.ui.activity

import android.os.Bundle

import com.yacine.newsapp.R

import com.yacine.newsapp.ui.base.BaseActivity




class MainActivity : BaseActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)




    }
}
